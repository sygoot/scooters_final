package com.Hulajnogi.App.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RentalRequest {
    private Long idVehicle;
    private Long idUser;

}
