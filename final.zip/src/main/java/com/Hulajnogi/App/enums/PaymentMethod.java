package com.Hulajnogi.App.enums;

public enum PaymentMethod {
    CASH,
    ONLINE
}
