package com.Hulajnogi.App.enums;

public enum VehicleStatus {
    AVAILABLE,
    IN_USE,

    UNDER_MAINTENANCE,
    OUT_OF_SERVICE
}
