package com.Hulajnogi.App.enums;

public enum Position {
    X,
    Y,
    Z,
    }
