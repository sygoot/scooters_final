package com.Hulajnogi.App.enums;

public enum ScooterType {
    ELECTRIC_SCOOTER,
    ELECTRIC_BIKE,
    MANUAL_SCOOTER // Dodaj inne typy zgodnie z wymaganiami
}
