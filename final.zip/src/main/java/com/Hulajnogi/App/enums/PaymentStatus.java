package com.Hulajnogi.App.enums;

public enum PaymentStatus {
    in_progress,
    refunded,
    complete,
    cancelled
    }
