package com.Hulajnogi.App.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER,
    EMPLOYEE
}
